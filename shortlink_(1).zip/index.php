
<?php
include "tools.php";
if( !isset($_GET['k']) || empty($_GET['k']) ){
	redirect('./login.php');
	}else{
		$url = $_GET['k'];
		//echo $id;
		
	if( file_exists("db/$url.txt") ){
		$urlasli = file_get_contents("db/$url.txt");
		
		$parts = explode("|",$urlasli);
		

?>



<!DOCTYPE html>
 <html lang="en">
 <head>
 	<meta charset="UTF-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1.0">
 	<title>SELAMAT DATANG</title>
 	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
 	<style>
.button-63 {
  align-items: center;
  background-image: linear-gradient(144deg,#000000, #000000 50%,#000000);
  border: 0;
  border-radius: 8px;
  box-shadow: rgba(151, 65, 252, 0.2) 0 15px 30px -5px;
  box-sizing: border-box;
  color: ##FFFFFF;
  display: flex;
  font-family: Phantomsans, sans-serif;
  font-size: 22px;
  justify-content: center;
  line-height: 1em;
  max-width: 100%;
  min-width: 100px;
  padding: 19px 24px;
  text-decoration: none;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  white-space: nowrap;
  cursor: pointer;
}

.button-63:active,
.button-63:hover {
  outline: 0;
}

@media (min-width: 760px) {
  .button-63 {
    font-size: 24px;
    min-width: 196px;
  }
}
 	</style>
 </head>
 <body>

 	

 	<div class="container mt-5">
 		<center><h1 class="p-2">
</h1>
</p1>
 			
 		<a href="<?= $parts[0] ?>"<div class="button-63">𝗞𝗹𝗶𝗸 𝗨𝗻𝘁𝘂𝗸 𝗟𝗮𝗻𝗷𝘂𝘁𝗸𝗮𝗻</div></a>
 	</div>
 	
 </body>
 </html>
 
 
 
 </center></div></body></html>



<?php

}else{
		redirect('./login.php');
	}
   
}
?>



