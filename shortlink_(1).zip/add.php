<?php
include "tools.php";
$adonxd = file_get_contents("adonxd.txt");
if(empty($_GET['adonxd'])){
redirect('./login.php');
}
if($_GET['adonxd'] == $adonxd){

$adonxd = $_GET['adonxd'];

alert('Benar Kata sandi nya adalah '.$adonxd.'');
$id = bin2hex(random_bytes(4));

if($_POST){
	$url = $_POST['url'];
	
	if($url != null)
	{
		$data = $url."|".$header."|".$paragraf."|".$title;
	$db = "db/";
	$bikin = file_put_contents($db.$id.".txt", $data);
	if( $bikin ){
		$website = 'https://'.$_SERVER['SERVER_NAME'].'/?k=';
		$short_link = $website.$id;
		$response = $short_link;
		redirect($response);
	}else{
	
	}
}else{
		
		alert('𝗠𝗮𝘀𝘂𝗸𝗶𝗻 𝗪𝗲𝗯 𝗠𝘂 𝗠𝗲𝗸');
		redirect('./add.php');
		exit();
		}
	//edirect($response);
}else{
?>
	

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Masukin Webp Lu</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="login">
<form method="POST" action="" autocomplete="off">
<input type="url" autofocus name="url" placeholder="Link Web Lu" required="required" />
<button type="submit" class="btn btn-primary btn-block btn-large">Create</button>
</form>
</div>
</body>
</html>
<?php
}
}else{
	redirect('./login.php');
	}
?>