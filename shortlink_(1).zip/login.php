<?php
date_default_timezone_set("Asia/Makassar");
include "tools.php";
	$adonxd = file_get_contents("adonxd.txt");
if(isset($_POST['adonxd']))
{
    
        if($adonxd == $_POST['adonxd'])
        {
            $hasil = TRUE;
            $adonxd = $_POST['adonxd'];
        }else{
        	$hasil = FALSE;
        	}
    
    
    if($hasil){ 	
    redirect('./add.php?adonxd='.$adonxd.'');
    	}
    	}
?>
<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Ndottz Host</title>

<link rel="stylesheet" href="css/style.css">

</head>

<body>
<br>
<div class="login">

<form method="POST" action="" autocomplete="off">
<br>
	<br>
		<br>
		<br>
	<br>
		<br>
<input type="text" autofocus name="adonxd" placeholder="Password" required="required" />

<button type="submit" class="btn btn-primary btn-block btn-large">Submit</button>

</form>

</div>

</body>

</html>