<?php 
$namaress = "WEB CAHYO SR ||";
$email = "emailmu@gmail.com";
$judul = "CEWEK SANGE";
$ukuran = "17MB";
?>