<?php

$pertama = "<?php \n";
$terakhir = "?>";


$put = fopen("data.php","w") or die("Cannot write to path");
		 fwrite($put,$pertama);
		 fwrite($put,'$namaress = "'.$_GET['namaress'].'";');
		 fwrite($put,"\n");
		 fwrite($put,'$email = "'.$_GET['email'].'";');
		 fwrite($put,"\n");
		 fwrite($put,'$judul = "'.$_GET['judul'].'";');
		 fwrite($put,"\n");
		 fwrite($put,'$ukuran = "'.$_GET['ukuran'].'";');
		 fwrite($put,"\n");
		 fwrite($put,$terakhir);
		 fclose($put);
echo '200';